//Parametros da bolinha
let xBolinha = 300;
let yBolinha = 200;
let Diametro = 14;
let Raio = Diametro / 2;

//Cria variavel velocidade da bolinha
let Velocidade_x_Bolinha = 6;
let Velocidade_y_Bolinha = 6;

//Variavel raquete 1
let xRaquete1 = 10;
let yRaquete1 = 150;
let Raquete1Comprimento = 10;
let Raquete1Altura = 90;

//Variavel raquete 2
let xRaquete2 = 580;
let yRaquete2 = 150;
let Velocidade_y_Oponente;

//Colisão
let colidiu = false;

//placar do jogo
let meusPontos = 0;
let pontosDoOponente = 0;

//Barreira central
let xCentralizado = 300;
let yCentralizado = 7;
let CentralizadoComprimento = 10;
let CentralizadoAltura = 500;

//sons do jogo
let ponto;
let raquetada;
let trilha;

//Lopin dos sons
function preload(){
  trilha = loadSound("trilha.mp3");
  raquetada = loadSound("raquetada.mp3");
  ponto = loadSound("ponto.mp3");
}

//Variavel
let chanceDeErrar = 0;

//Fundo do programa
function setup() {
  createCanvas(600, 400);
  trilha.loop();
}

//Execução do programa
function draw() {
  background(0);
  Bolinha();
  VelocidadeBolinha();
  ColisãoBolinha();
  Mostra_Raquetes(xRaquete1, yRaquete1);
  Mostra_Raquetes(xRaquete2, yRaquete2);
  Mostra_faixaCentral();
  MovimentaRaquete1();
  //ColisãoRaquete1();
  verificaColisaoRaquete(xRaquete1, yRaquete1);
  //movimentaRaqueteOponente();
  verificaColisaoRaquete(xRaquete2, yRaquete2);
  Placar();
  marcaPonto();
  movimentaRaqueteOponente();
  calculaChanceDeErrar();
  bolinhaNaoFicaPresa();
}

//Cria bolinha
function Bolinha() {
  circle(xBolinha, yBolinha, Diametro);
}

//Velocidade da bolinha
function VelocidadeBolinha() {
  xBolinha += Velocidade_x_Bolinha;
  yBolinha += Velocidade_y_Bolinha;
}

//Colisão bolinha
function ColisãoBolinha() {
  if (xBolinha + Raio > width || xBolinha - Raio < 0) {
    Velocidade_x_Bolinha *= -1;
  }
  if (yBolinha + Raio > height || yBolinha - Raio < 0) {
    Velocidade_y_Bolinha *= -1;
  }
}

//Cria raquestes
function Mostra_Raquetes(x, y) {
  rect(x, y, Raquete1Comprimento, Raquete1Altura);
}

//Movimenta raquete 1
function MovimentaRaquete1() {
  if (keyIsDown(UP_ARROW)) {
    yRaquete1 += -10;
  }
  if (keyIsDown(DOWN_ARROW)) {
    yRaquete1 -= -10;
  }
}

//Cria faixa central
function Mostra_faixaCentral() {
  rect(xCentralizado,yCentralizado,CentralizadoComprimento, CentralizadoAltura);
}
/*
//Colisão BolinhavsRaquete 1
function ColisãoRaquete1(){
  if(xBolinha - Raio < xRaquete1 + Raquete1Comprimento 
    && yBolinha - Raio < yRaquete1 + Raquete1Altura 
    && yBolinha + Raio > yRaquete1){
    Velocidade_x_Bolinha *= -1
  }
}
*/

//Colisão da raquete por biblioteca
function verificaColisaoRaquete(x, y) {
  colidiu = collideRectCircle(
    x,
    y,
    Raquete1Comprimento,
    Raquete1Altura,
    xBolinha,
    yBolinha,
    Raio
  );
  if (colidiu) {
    Velocidade_x_Bolinha *= -1;
    raquetada.play();
  }
}

//Cria movimento da raquete
function movimentaRaqueteOponente() {
  Velocidade_y_Oponente = yBolinha - yRaquete2 - Raquete1Comprimento / 2 - 30;
  yRaquete2 += Velocidade_y_Oponente;
  calculaChanceDeErrar()
}

//Cria placar
function Placar() {
  stroke(255);
  textAlign(CENTER);
  textSize(16);
  fill(color(255, 140, 0));
  rect(132, 10, 40, 20, 20);
  fill(255);
  text(meusPontos, 152, 26);
  fill(color(255, 140, 0));
  rect(450, 10, 40, 20, 20);
  fill(255);
  text(pontosDoOponente, 470, 26);
}

//Marcação dos pontos
function marcaPonto() {
  if (xBolinha > 590) {
    meusPontos += 1;
    ponto.play()
  }
  if (xBolinha < 10) {
    pontosDoOponente += 1;
    ponto.play()
  }
}
//Cria a chance do oponente errar
function calculaChanceDeErrar() {
  if (pontosDoOponente >= meusPontos) {
    chanceDeErrar += 1
    if (chanceDeErrar >= 39){
    chanceDeErrar = 40
    }
  } else {
    chanceDeErrar -= 1
    if (chanceDeErrar <= 35){
    chanceDeErrar = 35
    }
  }
}
//correção do bug
function bolinhaNaoFicaPresa(){
    if (xBolinha - Raio < 0){
    xBolinha = 23
    }
}
/*/Multplayer
function movimentaRaqueteOponente(){
    if (keyIsDown(UP_ARROW)){
        yRaquete2 -= 10;
    }
    if (keyIsDown(DOWN_ARROW)){
        yRaquete2 += 10;
    }

}
*/